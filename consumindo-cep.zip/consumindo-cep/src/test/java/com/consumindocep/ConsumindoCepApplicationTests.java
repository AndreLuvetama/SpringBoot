package com.consumindocep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumindoCepApplicationTests {

	@Test
	void contextLoads() {
	}

}
